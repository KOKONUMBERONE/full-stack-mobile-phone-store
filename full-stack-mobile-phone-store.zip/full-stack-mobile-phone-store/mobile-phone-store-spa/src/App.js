// import logo from './logo.svg';
import './App.css';
import Customer from './Screen/Customer';
import Phone from './Screen/Phone';
import Order from './Screen/Order';

function App() {
  return (
    <div>
      <Customer />
      <Phone />
      <Order />
    </div>
  );
}

export default App;
