import React, { useEffect, useState } from 'react';
import { Button } from 'react-bootstrap';
import axios from 'axios';

const Order = () => {
    const [Data, setData] = useState(null);

    const GetOrderData = () => {
        const url = 'http://localhost:8000/api/orders';
        axios.get(url)
            .then(response => {
                console.log("API response:", response);
                const { message, data } = response.data;

                if (response.status !== 200) {
                    alert(message, response.status);
                } else {
                    setData(data);
                    console.log(data);
                }
            })
            .catch(err => {
                console.log(err);
            });
    };

    useEffect(() => {
        GetOrderData();
    }, []);

    return (
        <div>
            {/* New code for rendering orders table */}
            {Data && (
                <div className='row'>
                    <div className='table-responsive'>
                        <table className='table table-striped table-hover table-bordered'>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer</th>
                                    <th>Phone(s)</th>
                                    <th>Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                {Data.map((order) =>
                                    <tr key={order._id}>
                                        <td>{order._id}</td>
                                        <td>{order.customer.firstName} {order.customer.lastName}</td>
                                        <td>
                                            {order.items.map((item, index) => (
                                                <div key={index}>
                                                    {item.quantity} x {item.phone.manufacturer} {item.phone.model}
                                                </div>
                                            ))}
                                        </td>
                                        <td>
                                            €{order.items.reduce((total, item) => total + (item.quantity * item.phone.price), 0)}
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}

export default Order;
