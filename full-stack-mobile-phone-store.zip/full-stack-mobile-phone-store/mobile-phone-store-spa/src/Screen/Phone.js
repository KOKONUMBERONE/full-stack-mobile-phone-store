import React, { useEffect, useState } from 'react';
import { Button } from 'react-bootstrap';
import axios from 'axios';

const Phone = () => {
  const [Data, setData] = useState(null);

  const GetPhoneData = () => { // Define a function called GetPhoneData
    const url = 'http://localhost:8000/api/phones'; // Declare a constant variable called url that contains the API URL to fetch customer data
    axios.get(url) // Use axios to send a GET request to the API endpoint
      .then(response => { // Handle the response of the GET request using a promise
        console.log("API response:", response); // Log the response object to the console for debugging purposes
        
        const { message, data } = response.data; // Extract the message and data from the API response object using object destructuring
      
        if (response.status !== 200) { // Check if the response status is not 200
          alert(message, response.status); // Display an alert with the message and response status
        } else { // If the response status is 200
          setData(data); // Set the state variable Data to the fetched data
          console.log(data); // Log the fetched data to the console for debugging purposes
        }
      })
      .catch(err => { // Handle any errors that occur during the GET request using a catch statement
        console.log(err); // Log the error to the console for debugging purposes
      });
  };

  useEffect(() => {
    GetPhoneData();
  }, []);

  return (
    <div>
      <div className='row'>
      </div>
      {Data && (
        <div className='row'>
          <div className='table-responsive'>
            <table className='table table-striped table-hover table-bordered'>
              <thead>
                <tr>
                  <th>Manufacturer</th>
                  <th>Model</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                {Data.map((item) =>
                  <tr key={item._id}>
                    <td>{item.manufacturer}</td>
                    <td>{item.model}</td>
                    <td>{item.price}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export default Phone;
