/*This code defines a React functional component called Customer. It imports several modules, including React, useState, useEffect, Button, Modal, Form, and axios.
The component defines some state variables using the useState hook: Data and formValues. It also defines a function GetCustomerData that uses the axios library to make an HTTP GET request to an API endpoint, and a function handleChange that updates the formValues state variable based on user input.
The component defines several other functions, including updateCustomer, handleSubmit, handleEditClick, and deleteCustomer, that use the axios library to make HTTP requests to various API endpoints.
The component also defines a useEffect hook that calls GetCustomerData on mount.
The component renders a table of customer data if Data is not null, and a form to add or edit customer data. The form fields are pre-populated with values from the formValues state variable, and the form's onSubmit handler calls handleSubmit.
The component exports the Customer function as the default export.
*/


import React, { useEffect, useState } from 'react';
import { Button, Modal } from 'react-bootstrap';
import { Form } from 'react-bootstrap';
import axios from 'axios';

const Customer = () => {
  const [Data, setData] = useState(null); // Declare a state variable called Data and initialize it to null using useState

  const GetCustomerData = () => { // Define a function called GetCustomerData
    const url = 'http://localhost:8000/api/customers'; // Declare a constant variable called url that contains the API URL to fetch customer data
    axios.get(url) // Use axios to send a GET request to the API endpoint
      .then(response => { // Handle the response of the GET request using a promise
        console.log("API response:", response); // Log the response object to the console for debugging purposes
        
        const { message, data } = response.data; // Extract the message and data from the API response object using object destructuring
      
        if (response.status !== 200) { // Check if the response status is not 200
          alert(message, response.status); // Display an alert with the message and response status
        } else { // If the response status is 200
          setData(data); // Set the state variable Data to the fetched data
          console.log(data); // Log the fetched data to the console for debugging purposes
        }
      })
      .catch(err => { // Handle any errors that occur during the GET request using a catch statement
        console.log(err); // Log the error to the console for debugging purposes
      });
  };
  
  const [formValues, setFormValues] = useState({ // Declare a state variable called formValues and initialize it to an object with empty string values using useState
    firstName: '',
    lastName: '',
    email: '',
    mobile: '',
    homeAddress: { addressLine1: '', town: '', county: '', eircode: '' },
    shippingAddress: { addressLine1: '', town: '', county: '', eircode: '' },
  });

  const handleChange = (e) => { // Define a function called handleChange that takes an event object as its parameter
    const { name, value } = e.target; // Destructure the name and value properties from the event target object

    if (name.startsWith("homeAddress")) { // Check if the name starts with "homeAddress"
      const fieldName = name.slice("homeAddress".length + 1); // Get the field name from the name attribute by removing "homeAddress" and the following dot
      setFormValues({ // Update the formValues state variable with the new value
        ...formValues,
        homeAddress: { ...formValues.homeAddress, [fieldName]: value }, // Use the spread operator to copy the existing homeAddress object and update the specific field with the new value
      });
    } else if (name.startsWith("shippingAddress")) { // Check if the name starts with "shippingAddress"
      const fieldName = name.slice("shippingAddress".length + 1); // Get the field name from the name attribute by removing "shippingAddress" and the following dot
      setFormValues({ // Update the formValues state variable with the new value
        ...formValues,
        shippingAddress: { ...formValues.shippingAddress, [fieldName]: value }, // Use the spread operator to copy the existing shippingAddress object and update the specific field with the new value
      });
  } else {
    setFormValues({
      ...formValues,
      [name]: value,
    });
  }
};

// This function updates a customer record in the database
const updateCustomer = (id) => {
  const url = `http://localhost:8000/api/customers/${id}`;

  axios
    .put(url, formValues)
    .then((response) => {
      if (response.status === 200) {
        alert("Employee updated successfully");
        GetCustomerData(); // Fetch the updated data
      } else {
        alert("An error occurred while updating the employee");
      }
    })
    .catch((error) => {
      console.log(error);
    });
};

// This function handles the form submit event
const handleSubmit = (e) => {
  e.preventDefault();

  if (editMode) {
    // Update an existing record
    const id = formValues._id;
    updateCustomer(id);
  } else {
    // Add a new record
    const url = "http://localhost:8000/api/customers";
    axios
      .post(url, formValues)
      .then((response) => {
        if (response.status === 201) {
          alert("Customer added successfully");
          GetCustomerData(); // Fetch the updated data
        } else {
          alert("An error occurred while adding the customer");
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }
};

// This state variable keeps track of whether the form is in edit mode or not
const [editMode, setEditMode] = useState(false);


const handleEditClick = (item) => {
  setFormValues({
    _id: item._id, 
    firstName: item.firstName,
    lastName: item.lastName,
    email: item.email,
    mobile: item.mobile,
    homeAddress: item.homeAddress,
    shippingAddress: item.shippingAddress,
  });
  setEditMode(true);
};



const deleteCustomer = (id) => {
const url = `http://localhost:8000/api/customers/${id}`;

axios
    .delete(url)
    .then((response) => {
    if (response.status === 200) {
        alert("Employee deleted successfully");
        GetCustomerData(); // Fetch the updated data
    } else {
        alert("An error occurred while deleting the employee");
    }
    })
    .catch((error) => {
    console.log(error);
    });
};
      

  console.log(Data);

  useEffect(() => {
    GetCustomerData();
  }, []);

  return (
    <div>
      <div className='row'>
      </div>
      {Data && ( 
        <div className='row'>
          <div className='table-responsive'>
            <table className='table table-striped table-hover table-bordered'>
              <thead>
                <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Mobile</th>
                  <th>Home Address</th>
                  <th>Shipping Address</th>
                  <th>Action</th> 
                </tr>
              </thead>
              <tbody>
                {Data.map((item) =>
                  <tr key={item._id}>
                    <td>{item.firstName}</td>
                    <td>{item.lastName}</td>
                    <td>{item.email}</td>
                    <td>{item.mobile}</td>
                    <td>{item.homeAddress.addressLine1}, {item.homeAddress.town}, {item.homeAddress.county}, {item.homeAddress.eircode}</td>
                    <td>{item.shippingAddress.addressLine1}, {item.shippingAddress.town}, {item.shippingAddress.county}, {item.shippingAddress.eircode}</td>
                    <td>
                        <Button variant="danger" onClick={() => deleteCustomer(item._id)}>Delete</Button>
                        <Button variant="warning" onClick={() => handleEditClick(item)}>Edit</Button> {/* New Edit button */}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            <Form onSubmit={handleSubmit}>
            <Form.Group>
              <Form.Label>First Name</Form.Label>
              <Form.Control type="text" name="firstName" value={formValues.firstName} onChange={handleChange} />
            </Form.Group>
            
            <Form.Group>
              <Form.Label>Last Name</Form.Label>
              <Form.Control type="text" name="lastName" value={formValues.lastName} onChange={handleChange} />
            </Form.Group>
            
            <Form.Group>
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" name="email" value={formValues.email} onChange={handleChange} />
            </Form.Group>
            
            <Form.Group>
              <Form.Label>Mobile</Form.Label>
              <Form.Control type="text" name="mobile" value={formValues.mobile} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>Home Address Line 1</Form.Label>
              <Form.Control type="text" name="homeAddress.addressLine1" value={formValues.homeAddress.addressLine1} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>Town</Form.Label>
              <Form.Control type="text" name="homeAddress.town" value={formValues.homeAddress.town} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>County</Form.Label>
              <Form.Control type="text" name="homeAddress.county" value={formValues.homeAddress.county} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>Eircode</Form.Label>
              <Form.Control type="text" name="homeAddress.eircode" value={formValues.homeAddress.eircode} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>Shipping Address Line 1</Form.Label>
              <Form.Control type="text" name="shippingAddress.addressLine1" value={formValues.shippingAddress.addressLine1} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>Town</Form.Label>
              <Form.Control type="text" name="shippingAddress.town" value={formValues.shippingAddress.town} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>County</Form.Label>
              <Form.Control type="text" name="shippingAddress.county" value={formValues.shippingAddress.county} onChange={handleChange} />
            </Form.Group>

            <Form.Group>
              <Form.Label>Eircode</Form.Label>
              <Form.Control type="text" name="shippingAddress.eircode" value={formValues.shippingAddress.eircode} onChange={handleChange} />
            </Form.Group>

              <Button type="submit">Add Customer</Button>
            </Form>
          </div>
        </div>
      )}
    </div>
  );
}
export default Customer;
