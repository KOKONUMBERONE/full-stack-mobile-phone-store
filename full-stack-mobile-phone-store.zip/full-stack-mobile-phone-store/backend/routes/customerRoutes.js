/* This code exports an Express router that defines routes for handling HTTP 
requests related to customers. The routes correspond to different HTTP methods 
(POST, GET, PUT, DELETE) and are assigned to methods of a customerController 
object that handles the corresponding logic. The router is imported into 
the main server file and mounted at the /api/customers endpoint using the 
app.use() method.*/


// Import the Express library and create a new router object
const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customerController');

// Define routes for handling HTTP requests related to customers
router.post('/', customerController.create); // Route for creating a new customer
router.get('/', customerController.getAll); // Route for retrieving all customers
router.get('/:id', customerController.getById); // Route for retrieving a specific customer by ID
router.put('/:id', customerController.update); // Route for updating a specific customer by ID
router.delete('/:id', customerController.delete); // Route for deleting a specific customer by ID

module.exports = router;

