/* This code exports an Express router that defines routes for handling HTTP requests 
related to phones. The routes correspond to different HTTP methods (POST, GET, PUT, DELETE)
and are assigned to methods of a phoneController object that handles the corresponding logic.
The router is imported into the main server file and mounted at the /api/phones 
endpoint using the app.use() method.*/

// Import the Express library and create a new router object
const express = require('express');
const router = express.Router();
const phoneController = require('../controllers/phoneController');

// Define routes for handling HTTP requests related to phones
router.post('/', phoneController.create); // Route for creating a new phone record
router.get('/', phoneController.getAll); // Route for retrieving all phone records
router.get('/:id', phoneController.getById); // Route for retrieving a specific phone record by ID
router.put('/:id', phoneController.update); // Route for updating a specific phone record by ID
router.delete('/:id', phoneController.delete); // Route for deleting a specific phone record by ID

module.exports = router;

