/* This code exports an Express router that defines routes for handling HTTP requests 
related to order. The routes correspond to different HTTP methods (POST, GET, PUT, DELETE)
and are assigned to methods of a phoneController object that handles the corresponding logic.
The router is imported into the main server file and mounted at the /api/orders 
endpoint using the app.use() method.*/


const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// Define routes for handling HTTP requests related to orders
router.post('/', orderController.create); // Route for creating a new order
router.get('/', orderController.getAll); // Route for retrieving all orders
router.get('/:id', orderController.getById); // Route for retrieving a specific order by ID
router.get('/customer/:customerId', orderController.getOrdersByCustomerId); // Route for retrieving all orders by customer ID
router.get('/item/:phoneId', orderController.getItemPurchasers); // Route for retrieving all purchasers of a specific item
router.put('/:id', orderController.update); // Route for updating a specific order by ID
router.delete('/:id', orderController.delete); // Route for deleting a specific order by ID

module.exports = router;

