/* This code defines a Mongoose schema for an Order model that represents an order placed by a customer. 
The schema includes two fields: customer and items. The customer field is a reference to a Customer 
document and the items field is an array of objects, with each object representing an item in the order. 
The mongoose.model() method is used to create a Mongoose model named Order based on the OrderSchema object, 
which can be used to create, read, update, and delete documents in the corresponding MongoDB collection.*/


const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
  items: [
    {
      phone: { type: mongoose.Schema.Types.ObjectId, ref: 'Phone', required: true },
      quantity: { type: Number, required: true },
    },
  ],
});

module.exports = mongoose.model('Order', OrderSchema);
