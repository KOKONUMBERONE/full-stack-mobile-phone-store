/*This code defines a Mongoose schema for a Customer model that represents 
a customer's information. The schema includes properties such as title, firstName, 
lastName, mobile, email, homeAddress, and shippingAddress. The mongoose.model() 
method is used to create a Mongoose model named Customer based on the CustomerSchema 
object, which can be used to create, read, update, and delete documents in 
the corresponding MongoDB collection. */


const mongoose = require('mongoose');

const CustomerSchema = new mongoose.Schema({
  title: {
    type: String,
    required: false,
    enum: ['Mx', 'Ms', 'Mr', 'Mrs', 'Miss', 'Dr', 'Other']
  },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  mobile: { type: String, required: true },
  email: { type: String, required: true },
  homeAddress: {
    addressLine1: { type: String, required: true },
    addressLine2: String,
    town: { type: String, required: true },
    county: { type: String, required: true },
    eircode: { type: String, required: false },
  },
  shippingAddress: {
    addressLine1: { type: String, required: true },
    addressLine2: String,
    town: { type: String, required: true },
    county: { type: String, required: true },
    eircode: { type: String, required: false },
  },
});

module.exports = mongoose.model('Customer', CustomerSchema,);
