/*This code defines a Mongoose schema for a Phone model that represents a mobile phone. 
The schema includes three fields: manufacturer, model, and price. The mongoose.model() 
method is used to create a Mongoose model named Phone based on the PhoneSchema object, 
which can be used to create, read, update, and delete documents in the corresponding 
MongoDB collection. */

const mongoose = require('mongoose');

const PhoneSchema = new mongoose.Schema({
  manufacturer: { type: String, required: true },
  model: { type: String, required: true },
  price: { type: Number, required: true },
});


module.exports = mongoose.model('Phone', PhoneSchema);
