/*This code sets up a Node.js server using the Express framework and connects to a database using the connectDB function. 
It defines routes for handling requests to different endpoints related to customers, phones, orders, and goals. 
The server listens on port 8000 (or a specified environment variable) and starts using the app.listen() method.*/
// Reference: https://www.youtube.com/watch?v=-0exw-9YJBo&t=3047s and W3schools

/* Browser: Chrome V112.0.5615.138
 Operating System: Windows
*/

// Import required modules

const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const connectDB = require('./database');

// Import route modules
const customerRoutes = require('./routes/customerRoutes');
const phoneRoutes = require('./routes/phoneRoutes');
const orderRoutes = require('./routes/orderRoutes');

// Connect to the database
connectDB();


app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  next();
});


// Set up middleware for parsing JSON and URL-encoded data
app.use(bodyParser.json());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Define routes for handling requests to different endpoints
app.use('/api/customers', customerRoutes);
app.use('/api/phones', phoneRoutes);
app.use('/api/orders', orderRoutes);

// Set the server port to 3000 or a specified environment variable
const PORT = 8000;

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
