// Importing the Phone model
const Phone = require('../models/Phone');

// Controller function for creating a phone
exports.create = async (req, res) => {
  try {
    const phone = new Phone(req.body);
    await phone.save();
    res.status(201).json(phone);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error creating phone', error });
  }
};

// Controller function for getting all phones
exports.getAll = async (req, res) => {
  try {
    const phones = await Phone.find();
    res.status(200).json({ data: phones });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error retrieving phones', error });
  }
};

// Controller function for getting a specific phone by ID
exports.getById = async (req, res) => {
  try {
    const phone = await Phone.findById(req.params.id);
    if (!phone) {
      return res.status(404).json({ message: 'Phone not found' });
    }
    res.json(phone);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error retrieving phone', error });
  }
};

// Controller function for updating a phone
exports.update = async (req, res) => {
  try {
    const phone = await Phone.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!phone) {
      return res.status(404).json({ message: 'Phone not found' });
    }
    res.json(phone);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating phone', error });
  }
};

// Controller function for deleting a phone
exports.delete = async (req, res) => {
  try {
    const phone = await Phone.findByIdAndDelete(req.params.id);
    if (!phone) {
      return res.status(404).json({ message: 'Phone not found' });
    }
    res.json({ message: 'Phone deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error deleting phone', error });
  }
};