/*This code exports controller functions for CRUD operations on Customer documents, 
including creating, retrieving, updating, and deleting documents. These functions 
handle request data, interact with the database, and send appropriate responses. */


// Import the Customer model
const Customer = require('../models/Customer');

// Create a new customer
exports.create = async (req, res) => {
  try {
    const customer = new Customer(req.body);
    await customer.save();
    res.status(201).json({data: customer });
  } catch (error) {
    res.status(500).json({ message: 'Error creating customer', error });
  }
};

// Get all customers
exports.getAll = async (req, res) => {
  try {
    const customers = await Customer.find({});
    res.status(200).json({ data: customers });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving customers', error });
  }
};

// Get a customer by ID
exports.getById = async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      res.status(404).json({ message: 'Customer not found' });
      return;
    }
    res.status(200).json({data: customer });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving customer', error });
  }
};

// Update a customer
exports.update = async (req, res) => {
  try {
    const updatedCustomer = await Customer.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedCustomer) {
      res.status(404).json({ message: 'Customer not found' });
      return;
    }
    res.status(200).json({  data: updatedCustomer });
  } catch (error) {
    res.status(500).json({ message: 'Error updating customer', error });
  }
};

// Delete a customer
exports.delete = async (req, res) => {
  try {
    const deletedCustomer = await Customer.findByIdAndDelete(req.params.id);
    if (!deletedCustomer) {
      res.status(404).json({ message: 'Customer not found' });
      return;
    }
    res.status(200).json({  data: deletedCustomer });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting customer', error });
  }
};




