const Order = require('../models/Order');
const Customer = require('../models/Customer');
const Phone = require('../models/Phone');

//creating a new order
exports.create = async (req, res) => {
  try {
    const customer = await Customer.findById(req.body.customer);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    const order = new Order(req.body);
    await order.save();
    res.status(201).json({ message: 'Order created successfully', data: order });
  } catch (error) {
    res.status(500).json({ message: 'Error creating order', error });
  }
};

//retrieving all orders
exports.getAll = async (req, res) => {
  try {
    const orders = await Order.find().populate('customer items.phone');
    res.status(200).json({data: orders });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving orders', error });
  }
};

//retrieving a specific order by ID
exports.getById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('customer items.phone');
    if (!order) {
      res.status(404).json({ message: 'Order not found' });
      return;
    }
    res.status(200).json({  data: order });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving order', error });
  }
};

//retrieving all orders by customer ID
exports.getOrdersByCustomerId = async (req, res) => {
  try {
    const customerId = req.params.customerId;
    const orders = await Order.find({ customer: customerId }).populate('customer items.phone');
    res.status(200).json({data: orders });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving orders for customer', error });
  }
};

//retrieving all purchasers of a specific item
exports.getItemPurchasers = async (req, res) => {
  try {
    const phoneId = req.params.phoneId;
    const orders = await Order.find({ 'items.phone': phoneId }).populate('customer items.phone');
    const purchasers = orders.map(order => ({
      customer: order.customer,
      items: order.items.filter(item => item.phone._id.toString() === phoneId),
    }));
    res.status(200).json({ data: purchasers });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving purchasers for item', error });
  }
};

//updating a specific order by ID
exports.update = async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, req.body, { new: true }).populate('customer items.phone');
    if (!order) {
      res.status(404).json({ message: 'Order not found' });
      return;
    }
    res.status(200).json({ data: order });
  } catch (error) {
    res.status(500).json({ message: 'Error updating order', error });
  }
};

//deleting a specific order by ID
exports.delete = async (req, res) => {
  try {
    const order = await Order.findByIdAndDelete(req.params.id);
    if (!order) {
      res.status(404).json({ message: 'Order not found' });
      return;
    }
    res.status(200).json({  data: order });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting order', error });
  }
};



