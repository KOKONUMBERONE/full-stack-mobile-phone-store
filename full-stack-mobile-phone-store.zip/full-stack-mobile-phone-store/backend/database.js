/*This code exports an async function named connectDB that connects to a MongoDB database 
using the Mongoose library. The function logs a success message to the console if the 
connection is established successfully, and logs an error message and exits the process 
with a non-zero exit code if an error occurs.
*/

// Import the Mongoose library
const mongoose = require('mongoose');

// Define an async function that connects to the database
const connectDB = async () => {
  try {
    // Attempt to connect to the MongoDB database using Mongoose
    await mongoose.connect('mongodb+srv://simon:simon123@cluster0.nprym7k.mongodb.net/mereapp', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      // useFindAndModify: false,
      // useCreateIndex: true,
    });
    
    // Log a success message if the connection is established
    console.log('MongoDB connected successfully');
  } catch (error) {
    console.error('Error connecting to MongoDB', error);
    process.exit(1);
  }
};

// Export the connectDB function
module.exports = connectDB;


